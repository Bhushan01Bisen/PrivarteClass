import React from "react";
import Image from "./Image";
import Frame from "./Frame";



function Border() {

    return(
        
        <div className="box">
            
            <Image/>
            <Frame/>
        </div>
    )
    
}

export default Border;