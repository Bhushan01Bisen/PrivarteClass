import React from "react";

function Naame() {

    return(
        <div className="naame">

            <p className="name">arshadXbagwan<br /> <font className="name_2">アルシャド</font></p>
            

        </div>
    )
    
}

export default Naame;