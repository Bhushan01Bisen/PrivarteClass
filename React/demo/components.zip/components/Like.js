import React from "react";

function Like() {
  return <div className="like">
     <i class="fa-solid fa-heart"></i>
    
  </div>;
}
export default Like;